<script setup>
import { ref, computed, onMounted } from 'vue'
import { RouterLink, RouterView } from 'vue-router'
import Left from './assets/icon/icon-chevron-Left.png'
import Right from './assets/icon/icon-chevron-Right.png'
import Down from './assets/icon/icon-chevron-down-small.png'
import holidayIcon from './assets/icon/IconButton.png'
</script>

<template>
  <RouterView />
</template>
